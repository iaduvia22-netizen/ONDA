globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2a8bb30f7ba1e33e.js",
    "static/chunks/6becc987c4d81425.js",
    "static/chunks/30ea11065999f7ac.js",
    "static/chunks/9594749131c0d29f.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/turbopack-b923d504519700c7.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];